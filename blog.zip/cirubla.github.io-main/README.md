## 简介

这个仓库是编程随想博客的镜像，样式也原博客基本同步，也支持查看博文评论功能。你可以把整个仓库下载到你本地，点击index.html即可查看整个博客的文章和评论。

点击访问镜像:  https://cirubla.github.io

## 如何部署

你可以Clone一份副本到你本地，在然后去GitHub创建一个username.github.io的仓库，就能部署一个GitHub Pages，部署流程请参考: https://docs.github.com/en/pages/quickstart

你也可以把内容部署到Nginx或Apache这类Http服务上。

## 如何帮助

Fork一份自己的副本，Clone一份到本地，创建一个GitHub Pages的镜像，传播开就是最大的帮助。

## 问题反馈

这个仓库关闭了Issue，预防有人来捣乱导致仓库被关闭。如有问题反馈，移步: https://github.com/cirubla/blog-feeback/issues
